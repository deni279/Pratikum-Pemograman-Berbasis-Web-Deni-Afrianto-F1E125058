// Latihan Mandiri: Konversi suhu Celsius ke Fahrenheit, Reamur, dan Kelvin
const SUHU_MINIMUM = -273.15; // nol absolut dalam Celsius

function keFahrenheit(c) { return (c * 9 / 5) + 32; }
function keReamur(c) { return c * 4 / 5; }
function keKelvin(c) { return c + 273.15; }

function kategoriSuhu(c) {
  if (c < 0) return "Beku";
  else if (c < 20) return "Dingin";
  else if (c < 30) return "Normal";
  else if (c < 38) return "Hangat";
  return "Panas";
}

const skala = [
  { nama: "Fahrenheit", simbol: "°F", hitung: keFahrenheit },
  { nama: "Reamur", simbol: "°R", hitung: keReamur },
  { nama: "Kelvin", simbol: "K", hitung: keKelvin }
];

const form = document.getElementById("formSuhu");
const hasil = document.getElementById("hasil");

form.addEventListener("submit", function (event) {
  event.preventDefault();
  const celsius = Number(document.getElementById("celsius").value);

  if (Number.isNaN(celsius) || celsius < SUHU_MINIMUM) {
    hasil.innerHTML = `<p class="error">Suhu tidak valid (minimal ${SUHU_MINIMUM} °C).</p>`;
    console.log("Input ditolak:", celsius);
    return;
  }

  const konversi = {};
  let isi = `<p>Input: <strong>${celsius} °C</strong></p>`;

  for (let i = 0; i < skala.length; i++) {
    const nilai = skala[i].hitung(celsius);
    konversi[skala[i].nama] = nilai;
    isi += `<p>${skala[i].nama}: <strong>${nilai.toFixed(2)} ${skala[i].simbol}</strong></p>`;
  }

  const kategori = kategoriSuhu(celsius);
  isi += `<p>Kategori: <span class="kategori">${kategori}</span></p>`;
  hasil.innerHTML = isi;

  console.log("Input Celsius:", celsius);
  console.log("Hasil konversi:", konversi);
  console.log("Kategori:", kategori);
});
